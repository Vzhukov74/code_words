// Copyright 2023 Skip
//
// This is free software: you can redistribute and/or modify it
// under the terms of the GNU Lesser General Public License 3.0
// as published by the Free Software Foundation https://fsf.org

package skip.ui

import skip.lib.*

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier

class ZStack: View {
    internal val alignment: Alignment
    internal val content: ComposeBuilder

    constructor(alignment: Alignment = Alignment.center, content: () -> View) {
        this.alignment = alignment.sref()
        this.content = ComposeBuilder.from(content)
    }

    @Composable
    override fun ComposeContent(context: ComposeContext) {
        val views = content.collectViews(context = context)
        val idMap: (View) -> Any? = { it ->
            TagModifierView.strip(from = it.sref(), role = ComposeModifierRole.id)?.value
        }
        val ids = views.compactMap(transform = idMap)
        val rememberedIds = remember { -> mutableSetOf<Any>() }
        val newIds = ids.filter { it -> !rememberedIds.contains(it) }
        val rememberedNewIds = remember { -> mutableSetOf<Any>() }

        rememberedNewIds.addAll(newIds)
        rememberedIds.clear()
        rememberedIds.addAll(ids)

        if (ids.count < views.count) {
            rememberedNewIds.clear()
            val contentContext = context.content()
            ComposeContainer(eraseAxis = true, modifier = context.modifier) { modifier ->
                Box(modifier = modifier, contentAlignment = alignment.asComposeAlignment()) { ->
                    views.forEach { it -> it.Compose(context = contentContext) }
                }
            }
        } else {
            ComposeContainer(eraseAxis = true, modifier = context.modifier) { modifier ->
                val arguments = AnimatedContentArguments(views = views, idMap = idMap, ids = ids, rememberedIds = rememberedIds, newIds = newIds, rememberedNewIds = rememberedNewIds, composer = null)
                ComposeAnimatedContent(context = context, modifier = modifier, arguments = arguments)
            }
        }
    }

    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun ComposeAnimatedContent(context: ComposeContext, modifier: Modifier, arguments: AnimatedContentArguments) {
        AnimatedContent(modifier = modifier, targetState = arguments.views, transitionSpec = { ->
            EnterTransition.None togetherWith ExitTransition.None
        }, contentKey = { it -> it.map(arguments.idMap) }, content = { state ->
            val animation = Animation.current(isAnimating = transition.isRunning)
            if (animation == null) {
                arguments.rememberedNewIds.clear()
            }
            Box(contentAlignment = alignment.asComposeAlignment()) { ->
                for (view in state.sref()) {
                    val id = arguments.idMap(view)
                    var modifier: Modifier = Modifier
                    if ((animation != null) && (arguments.newIds.contains(id) || arguments.rememberedNewIds.contains(id) || !arguments.ids.contains(id))) {
                        val transition = TransitionModifierView.transition(for_ = view) ?: OpacityTransition.shared
                        val spec = animation.asAnimationSpec()
                        val enter = transition.asEnterTransition(spec = spec)
                        val exit = transition.asExitTransition(spec = spec)
                        modifier = modifier.animateEnterExit(enter = enter, exit = exit)
                    }
                    view.Compose(context = context.content(modifier = modifier))
                }
            }
        }, label = "ZStack")
    }

    companion object {
    }
}

