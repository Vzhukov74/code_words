package code_word.module

import skip.lib.*

open class code_wordModule {

    companion object: CompanionClass() {
    }
    open class CompanionClass {
    }
}
